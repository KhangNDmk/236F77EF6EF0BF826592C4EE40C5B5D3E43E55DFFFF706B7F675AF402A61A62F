/*
 * temp.h
 *
 *  Created on: Dec 8, 2018
 *      Author: MK
 */

#ifndef TEMP_H_
#define TEMP_H_
#ifdef __cplusplus
extern "C" {
#endif

/* Noi dung header */





/*Ket thuc noi dung header*/

#ifdef __cplusplus
}
#endif
#endif /* TEMP_H_ */
